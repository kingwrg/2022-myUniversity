var express = require('express');
var router = express.Router();

/* GET users listing. */
var user;
router.get('/', function(req, res, next) {
  user = req.session.user[0];
  res.send('respond with a resource');
});

/* GET users logout. */
router.get('/logout', function(req, res, next) {
  user = null;
  res.send('respond with a resource');
});

/* POST get shows. */
router.post('/getCurrentShow', function(req, res, next) {
  // Connect to the database
  req.pool.getConnection(function(err, connection) {
    if (err) {
      res.sendStatus(500);
      return;
    }
    var query = "CALL get_current_show ()"; //mark
    connection.query(query, [], function(err, rows, fields) {
      connection.release(); // release connection
      if (err) {
        res.sendStatus(500);
        return;
      }
      res.json(rows); //send response
    });
  });
});

/* POST get shows. */
router.post('/getAvailableSeats', function(req, res, next) {
  // Connect to the database
  req.pool.getConnection(function(err, connection) {
    if (err) {
      res.sendStatus(500);
      return;
    }
    var query = "CALL get_available_seats ()"; //mark
    connection.query(query, [req.body.show_id], function(err, rows, fields) {
      connection.release(); // release connection
      if (err) {
        res.sendStatus(500);
        return;
      }
      res.json(rows); //send response
    });
  });
});

/* POST get user bookings. */
router.post('/getBookings', function(req, res, next) {
  // Connect to the database
  req.pool.getConnection(function(err, connection) {
    if (err) {
      res.sendStatus(500);
      return;
    }
    var query = "CALL view_bookings (?)"; //mark
    connection.query(query, [req.body.user_id], function(err, rows, fields) {
      connection.release(); // release connection
      if (err) {
        res.sendStatus(500);
        return;
      }
      res.json(rows); //send response
    });
  });
});

/* POST user book. */
router.post('/book', function(req, res, next) {
  // Connect to the database
  req.pool.getConnection(function(err, connection) {
    if (err) {
      res.sendStatus(500);
      return;
    }
    var query = "CALL book (?,?,?)"; //mark
    connection.query(query, [req.body.user_id, req.body.seat_id, req.body.show_id], function(err, rows, fields) {
      connection.release(); // release connection
      if (err) {
        res.sendStatus(500);
        return;
      }
      res.json(rows); //send response
    });
  });
});

module.exports = router;
