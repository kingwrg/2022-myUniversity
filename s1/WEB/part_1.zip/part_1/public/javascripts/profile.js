$(document).ready(function () {
  // get recent and upcomming bookings
  var xhttp = new XMLHttpRequest();

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      vueinst.upcoming_bookings.splice(0);
      var bookings = JSON.parse(this.responseText);
      for (let booking of bookings) {
        booking['date'] = booking['date'].substring(0,10);
        vueinst.upcoming_bookings.push(booking);
      }
    }
  };

  xhttp.open("POST", "/users/getBookings", true);
  xhttp.send();


  // get username
  xhttp = new XMLHttpRequest();

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("username").innerHTML = this.responseText;
    }
  };

  xhttp.open("GET", "/users/username", true);
  xhttp.send();
});

var vueinst = new Vue({
  el: "#app",
  data: {
    upcoming_bookings: [],
  }
});

document.getElementById("makeBookings").onclick = function () {
  window.location = "./bookings.html";
};