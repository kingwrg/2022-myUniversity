$(document).ready(function () {
  // get current shows
  var xhttp = new XMLHttpRequest();

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      vueinst.current_shows.splice(0);
      var shows = JSON.parse(this.responseText);
      for (let show of shows) {
        show['date'] = show['date'].substring(0,10);
        vueinst.current_shows.push(show);
      }
    }
  };

  xhttp.open("POST", "/users/getCurrentShow", true);
  xhttp.send();

  // get all sections
  xhttp = new XMLHttpRequest();

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      vueinst.sections_list.splice(0);
      vueinst.sections_list.push("All");
      var sections = JSON.parse(this.responseText);
      for (let section of sections) {
        vueinst.sections_list.push(section['section_name']);
      }
    }
  };

  xhttp.open("POST", "/users/getAllSections", true);
  xhttp.send();
});

var vueinst = new Vue({
  el: "#app",
  data: {
    chosen_show: 0,
    current_shows: [],
    avail_seats: [],
    filter_seats: [],
    sections_list: [],
    chosen_section: "All",
  },
  watch: {
    chosen_section: function(val) {
      vueinst.filter_seats = vueinst.avail_seats.filter((value, index) => {
        if (val == "All") return true;
        if (value.section_name == val) return true;
      });
    }
  },
  methods: {
    openModal: function() {
      var modal = document.getElementById("seats_list");
      modal.style.display = "block";
    },
    closeModal: function() {
      var modal = document.getElementById("seats_list");
      modal.style.display = "none";
      vueinst.chosen_show = 0;
      vueinst.avail_seats.splice(0);
      vueinst.chosen_section = "All";
    },
    getAvailableSeats: function(show_id) {
      vueinst.avail_seats.splice(0);
      vueinst.chosen_show = show_id;
      var xhttp = new XMLHttpRequest();

      xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
          var seats = JSON.parse(this.responseText);
          for (let seat of seats) {
            vueinst.avail_seats.push(seat);
          }
          vueinst.filter_seats = vueinst.avail_seats;
        }
      };

      xhttp.open("POST", "/users/getAvailableSeats", true);
      xhttp.setRequestHeader("Content-type", "application/json");
      xhttp.send(JSON.stringify({ show_id:show_id }));
    },
    makeBooking: function(seat_id) {
      var xhttp = new XMLHttpRequest();

      xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
          alert("You have successfully maked a booking!");
          vueinst.getAvailableSeats(vueinst.chosen_show);
          vueinst.chosen_section = "All";
        }
      };

      xhttp.open("POST", "/users/book", true);
      xhttp.setRequestHeader("Content-type", "application/json");
      xhttp.send(JSON.stringify({ seat_id:seat_id , show_id:vueinst.chosen_show }));
    }
  }
});

document.getElementById("backProfile").onclick = function () {
  window.location = "./profile.html";
};